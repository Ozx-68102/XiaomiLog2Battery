# AUTO GENERATED FILE - DO NOT EDIT

import typing  # noqa: F401
from typing_extensions import TypedDict, NotRequired, Literal # noqa: F401
from dash.development.base_component import Component, _explicitize_args

ComponentType = typing.Union[
    str,
    int,
    float,
    Component,
    None,
    typing.Sequence[typing.Union[str, int, float, Component, None]],
]

NumberType = typing.Union[
    typing.SupportsFloat, typing.SupportsInt, typing.SupportsComplex
]


class Upload_ReactComponent(Component):
    """An Upload_ReactComponent component.
The Upload component

Keyword arguments:

- id (string; default 'default-dash-uploader-id'):
    User supplied id of this component.

- cancelButton (boolean; default True):
    Whether or not to have a cancel button.

- chunkSize (number; default 1024 * 1024):
    Size of file chunks to send to server.

- className (string; default 'dash-uploader-default'):
    Class to add to the upload component by default.

- completeStyle (dict; optional):
    Style when upload is completed (upload finished).

- completedClass (string; default 'dash-uploader-completed'):
    Class to add to the upload component when it is complete.

- completedMessage (string; default 'Complete! '):
    Message to display when upload completed.

- dashAppCallbackBump (number; default 0):
    A prop that is monitored by the dash app   Wheneven the value of
    this prop is changed,   all the props are sent to the dash
    application.     This is used in the dash callbacks.

- defaultStyle (dict; optional):
    Style attributes to add to the upload component.

- disableDragAndDrop (boolean; default False):
    Whether or not to allow file drag and drop.

- disabled (boolean; optional):
    Whether or not to allow file uploading.

- disabledClass (string; default 'dash-uploader-disabled'):
    Class to add to the upload component when it is disabled.

- disabledMessage (string; optional):
    Message to display when upload disabled.

- disabledStyle (dict; optional):
    Style when upload is disabled.

- failedFileNames (list of strings; optional):
    The names of the files that failed to upload.

- filetypes (list of strings; default undefined):
    List of allowed file types, e.g. ['jpg', 'png'].

- hoveredClass (string; default 'dash-uploader-hovered'):
    Class to add to the upload component when it is hovered.

- isUploading (boolean; default False):
    Whether the upload process is currently active.    True when
    uploading, False when idle or finished.

- maxFileSize (number; default 1024 * 1024 * 10):
    Maximum size per file in bytes.

- maxFiles (number; default 1):
    Maximum number of files that can be uploaded in one session.

- maxTotalSize (number; optional):
    Maximum total size in bytes.

- pauseButton (boolean; default True):
    Whether or not to have a pause button.

- pausedClass (string; default 'dash-uploader-paused'):
    Class to add to the upload component when it is paused.

- service (string; default '/API/dash-uploader'):
    The service to send the files to.

- simultaneousUploads (number; default 1):
    Number of simultaneous uploads to select.

- startButton (boolean; default True):
    Whether or not to have a start button.

- text (string; default 'Click Here to Select a File'):
    The string to display in the upload component.

- totalFilesCount (number; optional):
    Total number of files to be uploaded.

- totalFilesSize (number; optional):
    Total size of uploaded files to be uploaded (MB).     MB =
    1024*1024 bytes.

- upload_id (string; default ''):
    The ID for the upload event (for example, session ID).

- uploadedFileNames (list of strings; optional):
    The names of the files uploaded.

- uploadedFilesSize (number; optional):
    Size of uploaded files (MB). MB = 1024*1024 bytes.

- uploadingClass (string; default 'dash-uploader-uploading'):
    Class to add to the upload component when it is uploading.

- uploadingStyle (dict; optional):
    Style when upload is in progress."""
    _children_props: typing.List[str] = []
    _base_nodes = ['children']
    _namespace = 'dash_uploader'
    _type = 'Upload_ReactComponent'


    def __init__(
        self,
        maxFiles: typing.Optional[NumberType] = None,
        maxFileSize: typing.Optional[NumberType] = None,
        maxTotalSize: typing.Optional[NumberType] = None,
        chunkSize: typing.Optional[NumberType] = None,
        simultaneousUploads: typing.Optional[NumberType] = None,
        service: typing.Optional[str] = None,
        className: typing.Optional[str] = None,
        hoveredClass: typing.Optional[str] = None,
        disabledClass: typing.Optional[str] = None,
        pausedClass: typing.Optional[str] = None,
        completedClass: typing.Optional[str] = None,
        uploadingClass: typing.Optional[str] = None,
        defaultStyle: typing.Optional[dict] = None,
        disabledStyle: typing.Optional[dict] = None,
        uploadingStyle: typing.Optional[dict] = None,
        completeStyle: typing.Optional[dict] = None,
        text: typing.Optional[str] = None,
        disabledMessage: typing.Optional[str] = None,
        completedMessage: typing.Optional[str] = None,
        uploadedFileNames: typing.Optional[typing.Sequence[str]] = None,
        failedFileNames: typing.Optional[typing.Sequence[str]] = None,
        filetypes: typing.Optional[typing.Sequence[str]] = None,
        startButton: typing.Optional[bool] = None,
        pauseButton: typing.Optional[bool] = None,
        cancelButton: typing.Optional[bool] = None,
        disabled: typing.Optional[bool] = None,
        disableDragAndDrop: typing.Optional[bool] = None,
        onUploadErrorCallback: typing.Optional[typing.Any] = None,
        id: typing.Optional[typing.Union[str, dict]] = None,
        dashAppCallbackBump: typing.Optional[NumberType] = None,
        upload_id: typing.Optional[str] = None,
        totalFilesCount: typing.Optional[NumberType] = None,
        uploadedFilesSize: typing.Optional[NumberType] = None,
        totalFilesSize: typing.Optional[NumberType] = None,
        isUploading: typing.Optional[bool] = None,
        **kwargs
    ):
        self._prop_names = ['id', 'cancelButton', 'chunkSize', 'className', 'completeStyle', 'completedClass', 'completedMessage', 'dashAppCallbackBump', 'defaultStyle', 'disableDragAndDrop', 'disabled', 'disabledClass', 'disabledMessage', 'disabledStyle', 'failedFileNames', 'filetypes', 'hoveredClass', 'isUploading', 'maxFileSize', 'maxFiles', 'maxTotalSize', 'pauseButton', 'pausedClass', 'service', 'simultaneousUploads', 'startButton', 'text', 'totalFilesCount', 'totalFilesSize', 'upload_id', 'uploadedFileNames', 'uploadedFilesSize', 'uploadingClass', 'uploadingStyle']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'cancelButton', 'chunkSize', 'className', 'completeStyle', 'completedClass', 'completedMessage', 'dashAppCallbackBump', 'defaultStyle', 'disableDragAndDrop', 'disabled', 'disabledClass', 'disabledMessage', 'disabledStyle', 'failedFileNames', 'filetypes', 'hoveredClass', 'isUploading', 'maxFileSize', 'maxFiles', 'maxTotalSize', 'pauseButton', 'pausedClass', 'service', 'simultaneousUploads', 'startButton', 'text', 'totalFilesCount', 'totalFilesSize', 'upload_id', 'uploadedFileNames', 'uploadedFilesSize', 'uploadingClass', 'uploadingStyle']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args}

        super(Upload_ReactComponent, self).__init__(**args)

setattr(Upload_ReactComponent, "__init__", _explicitize_args(Upload_ReactComponent.__init__))
